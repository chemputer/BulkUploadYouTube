# get your own api key by going to https://developers.wargaming.net/applications/ click create a new application, and set apikey to the ID, so if it's ID: 12341234123412341234 
# set apikey = '12341234123412341234'
apikey = ''
NA_ClanID = 1000080147
NA_NCTA_ClanID = 1000085573
EU_ClanID = 500193646
ASIA_ClanID = 2000020210
RU_ClanID = 445108